import React from 'react';
import './styles.css'

const LoadingScreen = () => {
    return (
        <div className="loader">
        </div>
    )
}

export default LoadingScreen
