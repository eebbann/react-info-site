

## Advance Table Build With Dev-Express

Steps to run this project:

1. Run `yarn install` command
2. Run `yarn start` command to run the server
2. Run `yarn server` command to run the fake api

stack:

1. React
2. devexpress
3. MUI
4. Emotion


